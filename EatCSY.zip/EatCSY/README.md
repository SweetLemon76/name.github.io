# 吃掉催逝员

_🦌 网页小游戏 🥛_

</div>


## 简介

小游戏：吃掉催逝员（修改于EatKano）

## 原项目

线上版本:https://xingye.me/game/eatkano/index.php

Github Page:https://arcxingye.github.io/EatKano/index.html
